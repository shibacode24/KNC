<?php

namespace App\Http\Controllers\panel;

use Illuminate\Http\Request;

class MastersController extends Controller
{
    //
}
