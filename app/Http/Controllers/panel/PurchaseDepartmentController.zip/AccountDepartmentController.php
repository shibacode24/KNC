<?php

namespace App\Http\Controllers\panel;

use Illuminate\Http\Request;

class AccountDepartmentController extends Controller
{
    //
}
