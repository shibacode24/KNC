<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ReceivedMaterial extends Model
{
    use HasFactory;
    protected $table = 'received_material';
    protected $fillable = [
        'requested_material_id',
        'received_quantity',
        'material_unit_type_id',

    ];
}
