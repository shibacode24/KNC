<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AssignSite extends Model
{
    use HasFactory;
    protected $table = 'assign_site';
    protected $fillable = ['date', 'site_assign', 'supervisor'];
    public function sitename()
    {
        return $this->hasOne(Site::class, 'id', 'site_assign');
    }
    public function supervisorname()
    {
        return $this->hasOne(Supervisor::class, 'id', 'supervisor');
    }
}
